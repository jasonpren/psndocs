using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Project.Pages
{
    public class ManagerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
