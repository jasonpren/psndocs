using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Project.Pages
{
    public class DoctorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
